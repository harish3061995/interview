import {  Link } from "react-router-dom";

function Nav() {
    return (
      <h1 className="text-3xl font-bold underline">
        <ul className="App-header flex mb-10 justify-center items-center">  
              <li className="px-3">  
                <Link to="/">home</Link>  
              </li>  
              <li className="px-3">  
                <Link to="/form">form</Link>  
              </li>  
              <li className="px-3">  
                <Link to="/product">Product</Link>  
              </li>  
            </ul>  
         </h1>
  
    );
  }
  
  export default Nav;
  