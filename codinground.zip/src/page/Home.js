
import BarChart from '../component/BarChart';
import Doughnutchart from '../component/Doughnut';
import LineChart from '../component/LineChart';

  function Home() {
    return (
      <>
      <h1 className="text-3xl font-bold underline">
Home    </h1>
<br />

<div class="grid grid-cols-1 md:grid-cols-3 gap-16">
  <div><BarChart /></div>
  <div><LineChart /> </div>
  <div><Doughnutchart /></div>
</div>
      </>
  
    );
  }
  
  export default Home;
  