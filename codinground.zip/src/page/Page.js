import { Route, Routes } from "react-router";
import FormPage from "./FormPage";
import ProductsGrid from "./ProductsGrid";
// import Dashboard from "./dashboard";
import Home from "./Home";

function Page() {
    return (
        <Routes>              
            <Route exact path='/' element={< Home />}></Route>  
            {/* <Route exact path='/dashboard' element={< Dashboard />}></Route>   */}
            <Route exact path='/form' element={< FormPage />}></Route>  
            <Route exact path='/product' element={< ProductsGrid />}></Route>  
      </Routes> 
    );
  }
  
  export default Page;
  
  