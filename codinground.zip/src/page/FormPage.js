import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

const FormPage = () => {
  const initialValues = {
    email: '',
    password: '',
  };

  const validationSchema = Yup.object({
    email: Yup.string()
      .email('Invalid email format')
      .required('Email is required'),
    password: Yup.string()
      .min(8, 'Password must be at least 8 characters')
      .matches(/[A-Z]/, 'Password must contain at least one uppercase letter')
      .matches(/[a-z]/, 'Password must contain at least one lowercase letter')
      .matches(/[0-9]/, 'Password must contain at least one number')
      .matches(/[^A-Za-z0-9]/, 'Password must contain at least one special character')
      .required('Password is required'),
  });

  const handleSubmit = (values) => {
    console.log('Form data:', values);
  };

  return (
   <div className='flex items-center justify-center'>
     <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {() => (
        <Form>
          <div  className="flex flex-col mb-8" >
            <label className='mb-2' htmlFor="email">Email</label>
            <Field className="border border-2 border-gray-500 rounded-full p-2 h-9 min-w-96" type="email" id="email" name="email" />
            <ErrorMessage  name="email" component="div" className="error text-red-400" />
          </div>

          <div  className="flex flex-col mb-8" >
            <label  className='mb-2' htmlFor="password">Password</label>
            <Field  className="border border-2 border-gray-500 rounded-full	p-2 h-9 min-w-96" type="password" id="password" name="password" />
            <ErrorMessage name="password" component="div" className="error  text-red-400" />
          </div>
          <div  className="flex flex-col mb-8" >
          <button className="text-white bg-black  rounded-full p-2 h-9  w-40 m-auto" type="submit">Submit</button>
          </div>
        </Form>
      )}
    </Formik>
   </div>
  );
};

export default FormPage;
