import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router } from 'react-router-dom';  
import Nav from './page/Nav';
import Page from './page/Page';

function App() {
  return (
    <>
       <Router>  
           <div className="App">  
           <Nav />
           <Page />
          </div>  
       </Router>  

  </>

  );
}

export default App;
